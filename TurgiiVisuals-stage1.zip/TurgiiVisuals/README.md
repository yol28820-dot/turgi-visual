# Turgii Visuals

Minecraft **Java 1.21.4** için **sadece client tarafı** çalışan, Fabric tabanlı PvP görsel modu.
Sunucuya kurulum gerektirmez, sunucu oyun mantığına dokunmaz; hile, otomatik savaş, nişan yardımı,
erişim (reach) değişikliği veya paket manipülasyonu içermez.

> **Durum: Aşama 1 (temel + ClickGUI).** Bu aşama henüz bir gerçek `./gradlew build` ile derlenmedi
> (geliştirme ortamında Fabric/Mojang Maven sunucularına erişim yoktu). Derlenip oyunda denenene kadar
> "çalışıyor" denmemelidir. Derleme hataları çıkarsa bana gönderin, düzeltilecek.

## Gereksinimler

- Java **21**
- Minecraft **1.21.4**
- Fabric Loader **>= 0.16.10**
- Fabric API (1.21.4 sürümü)

## Derleme

```
./gradlew build          # Windows: gradlew.bat build
```

Başarılı olursa jar şurada olur: `build/libs/TurgiiVisuals-1.0.0.jar`
(`TurgiiVisuals-1.0.0-sources.jar` kaynak jar'ıdır, oyuna **atmayın**.)

İlk derleme Minecraft'ı indirip eşleştirdiği için birkaç dakika sürebilir ve internet ister.

## Bilgisayarsız derleme (GitHub Actions)

1. github.com'da ücretsiz hesap aç, yeni bir repo oluştur.
2. Bu klasörün **tüm içeriğini** (`.github` klasörü dahil) repoya yükle.
3. Repoda **Actions** sekmesi > son çalışma > en altta **Artifacts** > `TurgiiVisuals-jar` indir (zip'in içinde jar var).
4. Kırmızı hata çıkarsa çalışmanın **Build** adımındaki log'u kopyalayıp gönder.

## Kurulum

1. Minecraft 1.21.4 için Fabric Loader kur.
2. `TurgiiVisuals-1.0.0.jar` ve Fabric API jar'ını `.minecraft/mods/` klasörüne koy.
3. Oyunu başlat. ClickGUI'yi **K** tuşuyla aç/kapat (Kontroller menüsünde "Turgii Visuals" altından değiştirilebilir).

## Aşama 1'de olanlar

- Gradle + Fabric Loom projesi (Java 21, Minecraft 1.21.4, Yarn eşlemeleri)
- `ClientModInitializer`, `fabric.mod.json` (sadece client ortamı)
- Modül sistemi: `Module`, `Category`, `ModuleManager`; ayar türleri: açma/kapama, sayı (kaydırıcı),
  seçenek (dropdown), renk, düğme
- ClickGUI: koyu yarı saydam yuvarlak panel, kenar çubuğu (sadece modülü olan kategoriler görünür),
  arama, modül kartları, animasyonlu anahtarlar, kaydırıcı, dropdown, onay kutusu, renk seçici,
  tuş atama, sıfırlama düğmeleri, tooltip, kaydırma (fare tekerleği veya boş alanı sürükleme),
  ölçeklenebilir arayüz, 10 tema
- Modüller (şimdilik sadece bunlar gerçek ve çalışıyor olarak eklendi):
  - **HUD:** FPS, Coordinates, Clock (konum yüzdeyle, ölçek, renk, gölge, arka plan ayarlı)
  - **Settings:** Interface (tema, vurgu rengi, opaklık, animasyon hızı, köşe yarıçapı, GUI ölçeği, parıltı),
    Config (Save / Reload / Export / Import / Reset)
- Config: `config/turgii-visuals/config.json`, `hud.json`, `keybinds.json`; ayar değişince otomatik kaydedilir,
  oyundan çıkarken de kaydedilir. Bozuk dosya `.corrupt` olarak yedeklenir, varsayılanlara dönülür.

## GUI kullanımı

| İşlem | Nasıl |
| --- | --- |
| Modülü aç/kapat | Sağdaki anahtara tıkla (veya kart başlığına sağ tık) |
| Ayarları göster | Kart başlığına tıkla |
| Varsayılana döndür | Değişmiş ayarın yanındaki **R**, ya da ayar satırına sağ tık |
| Tuş ata | Kartı aç, "Keybind" kutusuna tıkla, bir tuşa bas (Backspace siler, Esc iptal) |
| Ara | Üstteki arama kutusuna tıkla |
| Kaydır | Fare tekerleği veya boş alanı sürükle (dokunmatik için) |

## Profil dışa/içe aktarma

`Config > Export Profile` → `config/turgii-visuals/export/turgii-profile.json`.
Bu dosyayı başkasına verebilirsin; `Import Profile` aynı konumdaki dosyayı okur.

## Sonraki aşamalar (henüz kodlanmadı)

HUD editörü (sürükle-bırak) ve kalan HUD modülleri, ESP, trail, hit particle, skybox, atmosfer/sis,
görsel efektler, crosshair, el/viewmodel, performans presetleri. Her aşama, önceki aşama derlendikten
sonra eklenecek.

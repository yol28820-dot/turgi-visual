package com.turgii.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.turgii.visuals.TurgiiVisualsClient;
import com.turgii.visuals.module.Category;
import com.turgii.visuals.module.Module;
import com.turgii.visuals.module.ModuleManager;
import com.turgii.visuals.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;

/**
 * config/turgii-visuals/ altındaki üç dosyayı yönetir:
 * <ul>
 *   <li>config.json  - HUD dışındaki modüllerin açık/kapalı durumu ve ayarları</li>
 *   <li>hud.json     - HUD kategorisindeki modüller</li>
 *   <li>keybinds.json - modül tuş atamaları</li>
 * </ul>
 * Ayar değişince "kirli" işaretlenir; tick içinde kısa bir gecikmeyle diske yazılır (her karede IO yok).
 */
public final class ConfigManager {
	private static final int FORMAT_VERSION = 1;
	private static final long AUTOSAVE_DELAY_MS = 1000L;
	private static final String EXPORT_REL = "config/turgii-visuals/export/turgii-profile.json";

	private static volatile boolean dirty;
	private static volatile long lastChange;

	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
	private final ModuleManager modules;
	private final Path dir;
	private final Path configFile;
	private final Path hudFile;
	private final Path keybindsFile;
	private final Path exportFile;

	public ConfigManager(ModuleManager modules) {
		this.modules = modules;
		this.dir = FabricLoader.getInstance().getConfigDir().resolve("turgii-visuals");
		this.configFile = dir.resolve("config.json");
		this.hudFile = dir.resolve("hud.json");
		this.keybindsFile = dir.resolve("keybinds.json");
		this.exportFile = dir.resolve("export").resolve("turgii-profile.json");
	}

	public static void markDirty() {
		dirty = true;
		lastChange = System.currentTimeMillis();
	}

	/** Her client tick'inde çağrılır. */
	public void tick() {
		if (dirty && System.currentTimeMillis() - lastChange >= AUTOSAVE_DELAY_MS) {
			save();
		}
	}

	public void saveIfDirty() {
		if (dirty) {
			save();
		}
	}

	// ------------------------------------------------------------------ yükleme

	/** Açılışta bir kez çağrılır. Dosya yoksa varsayılanlarla oluşturur. */
	public void load() {
		boolean firstRun = !Files.exists(configFile);
		applyFiles(readJson(configFile), readJson(hudFile), readJson(keybindsFile));
		if (firstRun) {
			save();
		}
		dirty = false;
	}

	/** GUI'deki "Reload From Disk" düğmesi. */
	public String reload() {
		applyFiles(readJson(configFile), readJson(hudFile), readJson(keybindsFile));
		dirty = false;
		return "Reloaded settings from disk.";
	}

	private void applyFiles(JsonObject config, JsonObject hud, JsonObject keybinds) {
		applyModules(config, false);
		applyModules(hud, true);
		applyKeybinds(keybinds);
	}

	private void applyModules(JsonObject root, boolean hud) {
		if (root == null || !root.has("modules") || !root.get("modules").isJsonObject()) {
			return;
		}
		for (Map.Entry<String, JsonElement> entry : root.getAsJsonObject("modules").entrySet()) {
			Module module = modules.byId(entry.getKey());
			if (module == null || (module.getCategory() == Category.HUD) != hud || !entry.getValue().isJsonObject()) {
				continue;
			}
			JsonObject data = entry.getValue().getAsJsonObject();
			if (module.isToggleable() && data.has("enabled") && data.get("enabled").isJsonPrimitive()
				&& data.getAsJsonPrimitive("enabled").isBoolean()) {
				module.setEnabled(data.get("enabled").getAsBoolean());
			}
			if (data.has("settings") && data.get("settings").isJsonObject()) {
				JsonObject saved = data.getAsJsonObject("settings");
				for (Setting<?> setting : module.getSettings()) {
					if (setting.isSerializable() && saved.has(setting.getName())) {
						setting.fromJson(saved.get(setting.getName()));
					}
				}
			}
		}
	}

	private void applyKeybinds(JsonObject root) {
		if (root == null) {
			return;
		}
		for (Module module : modules.all()) {
			module.setKeyCode(-1);
		}
		JsonObject binds = root.has("binds") && root.get("binds").isJsonObject() ? root.getAsJsonObject("binds") : null;
		if (binds == null) {
			return;
		}
		for (Map.Entry<String, JsonElement> entry : binds.entrySet()) {
			Module module = modules.byId(entry.getKey());
			JsonElement value = entry.getValue();
			if (module != null && module.isToggleable() && value.isJsonPrimitive()
				&& value.getAsJsonPrimitive().isNumber()) {
				module.setKeyCode(value.getAsInt());
			}
		}
	}

	private JsonObject readJson(Path path) {
		if (!Files.exists(path)) {
			return null;
		}
		try {
			JsonElement parsed = JsonParser.parseString(Files.readString(path));
			if (parsed.isJsonObject()) {
				return parsed.getAsJsonObject();
			}
			throw new JsonParseException("root is not a JSON object");
		} catch (IOException | JsonParseException | IllegalStateException e) {
			TurgiiVisualsClient.LOGGER.error("Could not read {} - keeping defaults and renaming it to .corrupt", path, e);
			try {
				Files.move(path, path.resolveSibling(path.getFileName() + ".corrupt"),
					StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException moveError) {
				TurgiiVisualsClient.LOGGER.error("Could not rename the broken file", moveError);
			}
			return null;
		}
	}

	// ------------------------------------------------------------------ kaydetme

	/** Üç dosyayı da yazar. GUI'ye gösterilecek mesajı döndürür. */
	public String save() {
		try {
			Files.createDirectories(dir);
			writeJson(configFile, buildModules(false));
			writeJson(hudFile, buildModules(true));
			writeJson(keybindsFile, buildKeybinds());
			dirty = false;
			return "Saved to config/turgii-visuals/";
		} catch (IOException e) {
			TurgiiVisualsClient.LOGGER.error("Could not save the config", e);
			return "Save failed - see the game log.";
		}
	}

	private JsonObject buildModules(boolean hud) {
		JsonObject root = new JsonObject();
		root.addProperty("version", FORMAT_VERSION);
		JsonObject mods = new JsonObject();
		for (Module module : modules.all()) {
			if ((module.getCategory() == Category.HUD) != hud) {
				continue;
			}
			JsonObject data = new JsonObject();
			if (module.isToggleable()) {
				data.addProperty("enabled", module.isEnabled());
			}
			JsonObject settings = new JsonObject();
			for (Setting<?> setting : module.getSettings()) {
				if (setting.isSerializable()) {
					settings.add(setting.getName(), setting.toJson());
				}
			}
			data.add("settings", settings);
			mods.add(module.getId(), data);
		}
		root.add("modules", mods);
		return root;
	}

	private JsonObject buildKeybinds() {
		JsonObject root = new JsonObject();
		root.addProperty("version", FORMAT_VERSION);
		JsonObject binds = new JsonObject();
		for (Module module : modules.all()) {
			if (module.isToggleable() && module.getKeyCode() >= 0) {
				binds.addProperty(module.getId(), module.getKeyCode());
			}
		}
		root.add("binds", binds);
		return root;
	}

	private void writeJson(Path path, JsonObject json) throws IOException {
		Path temp = path.resolveSibling(path.getFileName() + ".tmp");
		Files.writeString(temp, gson.toJson(json));
		Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
	}

	// ------------------------------------------------------------------ içe/dışa aktarma, sıfırlama

	public String exportProfile() {
		try {
			Files.createDirectories(exportFile.getParent());
			JsonObject profile = new JsonObject();
			profile.addProperty("version", FORMAT_VERSION);
			profile.add("config", buildModules(false));
			profile.add("hud", buildModules(true));
			profile.add("keybinds", buildKeybinds());
			writeJson(exportFile, profile);
			return "Exported to " + EXPORT_REL;
		} catch (IOException e) {
			TurgiiVisualsClient.LOGGER.error("Could not export the profile", e);
			return "Export failed - see the game log.";
		}
	}

	public String importProfile() {
		if (!Files.exists(exportFile)) {
			return "No profile found in config/turgii-visuals/export/";
		}
		JsonObject profile = readJson(exportFile);
		if (profile == null) {
			return "Import failed - the profile file is not valid JSON.";
		}
		JsonObject config = profile.has("config") && profile.get("config").isJsonObject()
			? profile.getAsJsonObject("config") : null;
		JsonObject hud = profile.has("hud") && profile.get("hud").isJsonObject()
			? profile.getAsJsonObject("hud") : null;
		JsonObject keybinds = profile.has("keybinds") && profile.get("keybinds").isJsonObject()
			? profile.getAsJsonObject("keybinds") : null;
		applyFiles(config, hud, keybinds);
		save();
		return "Imported profile and saved it.";
	}

	public String resetAll() {
		modules.resetAll();
		save();
		return "Everything was reset to defaults.";
	}
}

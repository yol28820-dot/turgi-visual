package com.turgii.visuals.gui;

/** Renk yardımcıları. "rgb" = 0xRRGGBB, "argb" = 0xAARRGGBB. */
public final class Colors {
	private Colors() {
	}

	public static int argb(int rgb, float alpha) {
		float a = alpha < 0f ? 0f : Math.min(alpha, 1f);
		return (Math.round(a * 255f) << 24) | (rgb & 0xFFFFFF);
	}

	public static int opaque(int rgb) {
		return 0xFF000000 | (rgb & 0xFFFFFF);
	}

	public static int lerp(int rgbA, int rgbB, float t) {
		float k = t < 0f ? 0f : Math.min(t, 1f);
		int r = Math.round(((rgbA >> 16) & 0xFF) * (1f - k) + ((rgbB >> 16) & 0xFF) * k);
		int g = Math.round(((rgbA >> 8) & 0xFF) * (1f - k) + ((rgbB >> 8) & 0xFF) * k);
		int b = Math.round((rgbA & 0xFF) * (1f - k) + (rgbB & 0xFF) * k);
		return (r << 16) | (g << 8) | b;
	}

	public static int hsvToRgb(float h, float s, float v) {
		float hue = h - (float) Math.floor(h);
		float hh = hue * 6f;
		int i = (int) hh;
		float f = hh - i;
		float p = v * (1f - s);
		float q = v * (1f - s * f);
		float t = v * (1f - s * (1f - f));
		float r;
		float g;
		float b;
		switch (i % 6) {
			case 0 -> {
				r = v;
				g = t;
				b = p;
			}
			case 1 -> {
				r = q;
				g = v;
				b = p;
			}
			case 2 -> {
				r = p;
				g = v;
				b = t;
			}
			case 3 -> {
				r = p;
				g = q;
				b = v;
			}
			case 4 -> {
				r = t;
				g = p;
				b = v;
			}
			default -> {
				r = v;
				g = p;
				b = q;
			}
		}
		return (Math.round(r * 255f) << 16) | (Math.round(g * 255f) << 8) | Math.round(b * 255f);
	}

	/** out[0]=hue, out[1]=sat, out[2]=value (hepsi 0..1). */
	public static void rgbToHsv(int rgb, float[] out) {
		float r = ((rgb >> 16) & 0xFF) / 255f;
		float g = ((rgb >> 8) & 0xFF) / 255f;
		float b = (rgb & 0xFF) / 255f;
		float max = Math.max(r, Math.max(g, b));
		float min = Math.min(r, Math.min(g, b));
		float d = max - min;
		float h;
		if (d == 0f) {
			h = 0f;
		} else if (max == r) {
			h = ((g - b) / d) % 6f;
		} else if (max == g) {
			h = (b - r) / d + 2f;
		} else {
			h = (r - g) / d + 4f;
		}
		h /= 6f;
		if (h < 0f) {
			h += 1f;
		}
		out[0] = h;
		out[1] = max == 0f ? 0f : d / max;
		out[2] = max;
	}
}

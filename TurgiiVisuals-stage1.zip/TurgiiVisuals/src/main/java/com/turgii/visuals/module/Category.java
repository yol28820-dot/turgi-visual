package com.turgii.visuals.module;

/**
 * ClickGUI kategorileri. Sadece en az bir modülü olan kategoriler GUI kenar çubuğunda gösterilir.
 */
public enum Category {
	COMBAT_VISUALS("Combat Visuals"),
	PLAYER("Player"),
	WORLD("World"),
	PARTICLES("Particles"),
	SKY("Sky"),
	HUD("HUD"),
	ANIMATION("Animation"),
	RENDER("Render"),
	MISC("Misc"),
	SETTINGS("Settings");

	private final String label;

	Category(String label) {
		this.label = label;
	}

	public String label() {
		return label;
	}
}

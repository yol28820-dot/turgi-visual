package com.turgii.visuals.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.turgii.visuals.config.ConfigManager;
import com.turgii.visuals.gui.Colors;

import java.util.Locale;

/**
 * RGB renk ayarı (0xRRGGBB). Renk seçici HSV çubuklarıyla çalıştığı için H/S/V ayrıca tutulur;
 * böylece doygunluk 0'a çekilince ton kaybolmaz.
 */
public final class ColorSetting extends Setting<Integer> {
	private final float[] tmp = new float[3];
	private float hue;
	private float sat;
	private float val;

	public ColorSetting(String name, String description, int rgb) {
		super(name, description, rgb & 0xFFFFFF);
		syncHsv();
	}

	public float getHue() {
		return hue;
	}

	public float getSat() {
		return sat;
	}

	public float getVal() {
		return val;
	}

	public void setHsv(float h, float s, float v) {
		hue = clamp01(h);
		sat = clamp01(s);
		val = clamp01(v);
		int rgb = Colors.hsvToRgb(hue, sat, val);
		if (rgb != value) {
			value = rgb;
			ConfigManager.markDirty();
		}
	}

	@Override
	public void set(Integer newValue) {
		super.set(newValue);
		syncHsv();
	}

	@Override
	protected Integer sanitize(Integer candidate) {
		return candidate == null ? null : (candidate & 0xFFFFFF);
	}

	private void syncHsv() {
		Colors.rgbToHsv(value, tmp);
		if (tmp[1] > 0f && tmp[2] > 0f) {
			hue = tmp[0];
		}
		sat = tmp[1];
		val = tmp[2];
	}

	private static float clamp01(float f) {
		return f < 0f ? 0f : Math.min(f, 1f);
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(String.format(Locale.ROOT, "#%06X", value));
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element == null || !element.isJsonPrimitive()) {
			return;
		}
		try {
			if (element.getAsJsonPrimitive().isNumber()) {
				set(element.getAsInt());
			} else {
				String text = element.getAsString().trim();
				if (text.startsWith("#")) {
					text = text.substring(1);
				}
				set(Integer.parseInt(text, 16));
			}
		} catch (NumberFormatException ignored) {
			// bozuk renk değeri: varsayılan korunur
		}
	}
}

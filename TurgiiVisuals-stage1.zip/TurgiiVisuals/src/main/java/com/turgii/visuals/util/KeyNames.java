package com.turgii.visuals.util;

import net.minecraft.client.util.InputUtil;

public final class KeyNames {
	private KeyNames() {
	}

	/** GLFW klavye kodunu okunabilir isme çevirir; -1 = atanmamış. */
	public static String of(int keyCode) {
		if (keyCode < 0) {
			return "None";
		}
		return InputUtil.Type.KEYSYM.createFromCode(keyCode).getLocalizedText().getString();
	}
}

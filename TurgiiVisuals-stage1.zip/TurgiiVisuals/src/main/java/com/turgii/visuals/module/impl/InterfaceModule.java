package com.turgii.visuals.module.impl;

import com.turgii.visuals.gui.Theme;
import com.turgii.visuals.module.Category;
import com.turgii.visuals.module.Module;
import com.turgii.visuals.setting.BooleanSetting;
import com.turgii.visuals.setting.ColorSetting;
import com.turgii.visuals.setting.ModeSetting;
import com.turgii.visuals.setting.NumberSetting;

/** ClickGUI'nin kendi görünüm ayarları. Kapatılamaz, sadece ayar tutar. */
public final class InterfaceModule extends Module {
	private final ModeSetting theme = add(new ModeSetting("Theme", "Color theme of the ClickGUI.",
		Theme.PURPLE.label, Theme.labels()));
	private final BooleanSetting customAccent = add(new BooleanSetting("Custom Accent",
		"Use your own accent color instead of the theme's accent.", false));
	private final ColorSetting accentColor = add(new ColorSetting("Accent Color",
		"Accent color used for highlights, switches and sliders.", Theme.PURPLE.accent));
	private final NumberSetting bgOpacity = add(new NumberSetting("Background Opacity",
		"How see-through the GUI window is. Lower = more transparent.", 1.0, 0.2, 1.0, 0.05));
	private final NumberSetting animSpeed = add(new NumberSetting("Animation Speed",
		"Speed of open/close, expand and toggle animations.", 1.0, 0.5, 3.0, 0.1));
	private final NumberSetting cornerRadius = add(new NumberSetting("Corner Radius",
		"Roundness of the window corners (cards use at most 6).", 6, 0, 10, 1));
	private final NumberSetting guiScale = add(new NumberSetting("GUI Scale",
		"Size of the ClickGUI. It shrinks automatically if the window would not fit on screen.", 1.0, 0.6, 1.5, 0.05));
	private final BooleanSetting glow = add(new BooleanSetting("Panel Glow",
		"Soft accent-colored glow around the window.", true));

	public InterfaceModule() {
		super("Interface", "Look and feel of this ClickGUI.", Category.SETTINGS, false);
		accentColor.visibleWhen(customAccent::isOn);
	}

	public Theme theme() {
		return Theme.byLabel(theme.get());
	}

	/** 0xRRGGBB */
	public int accent() {
		return customAccent.isOn() ? accentColor.get() : theme().accent;
	}

	public float bgOpacity() {
		return bgOpacity.getFloat();
	}

	public float animSpeed() {
		return animSpeed.getFloat();
	}

	public int radius() {
		return cornerRadius.getInt();
	}

	public float guiScale() {
		return guiScale.getFloat();
	}

	public boolean glow() {
		return glow.isOn();
	}
}

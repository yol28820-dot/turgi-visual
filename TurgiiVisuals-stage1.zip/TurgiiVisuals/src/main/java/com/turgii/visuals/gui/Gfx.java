package com.turgii.visuals.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/**
 * GUI çizim yardımcısı. Tüm koordinatlar "yerel" birimdedir (pencerenin sol üstü 0,0); burada
 * ölçek + ofset ile ekran koordinatına çevrilir. Matris ölçeklemesi sadece metin için kullanılır,
 * böylece scissor (kırpma) her zaman matrissiz ekran koordinatlarında çalışır.
 *
 * Yuvarlak köşeler, tam sayı satır dolgularıyla çizilir (DrawContext'te yuvarlak dikdörtgen yok).
 * Aynı bölgeye iki kez yarı saydam boyamamak için tüm parçalar birbirinden ayrıktır.
 */
final class Gfx {
	private static final int MAX_RADIUS = 32;
	private static final int[][] INSET_CACHE = new int[MAX_RADIUS + 1][];

	private DrawContext context;
	private TextRenderer font;
	private float scale = 1f;
	private float originX;
	private float originY;
	private float alpha = 1f;

	void begin(DrawContext context, TextRenderer font, float scale, float originX, float originY, float alpha) {
		this.context = context;
		this.font = font;
		this.scale = scale;
		this.originX = originX;
		this.originY = originY;
		this.alpha = alpha < 0f ? 0f : Math.min(alpha, 1f);
	}

	private int sx(float x) {
		return Math.round(originX + x * scale);
	}

	private int sy(float y) {
		return Math.round(originY + y * scale);
	}

	private int withAlpha(int argb) {
		int a = Math.round(((argb >>> 24) & 0xFF) * alpha);
		return (a << 24) | (argb & 0xFFFFFF);
	}

	// ---------------------------------------------------------------- şekiller

	void rect(float x, float y, float w, float h, int argb) {
		int color = withAlpha(argb);
		if ((color >>> 24) == 0) {
			return;
		}
		int x1 = sx(x);
		int y1 = sy(y);
		int x2 = sx(x + w);
		int y2 = sy(y + h);
		if (x2 <= x1) {
			x2 = x1 + 1;
		}
		if (y2 <= y1) {
			y2 = y1 + 1;
		}
		context.fill(x1, y1, x2, y2, color);
	}

	void roundRect(float x, float y, float w, float h, float radius, int argb) {
		int color = withAlpha(argb);
		if ((color >>> 24) == 0) {
			return;
		}
		int x1 = sx(x);
		int y1 = sy(y);
		int x2 = Math.max(x1 + 1, sx(x + w));
		int y2 = Math.max(y1 + 1, sy(y + h));
		int r = clampRadius(Math.round(radius * scale), x2 - x1, y2 - y1);
		if (r <= 0) {
			context.fill(x1, y1, x2, y2, color);
			return;
		}
		int[] in = insets(r);
		int i = 0;
		while (i < r) {
			int j = i;
			while (j + 1 < r && in[j + 1] == in[i]) {
				j++;
			}
			context.fill(x1 + in[i], y1 + i, x2 - in[i], y1 + j + 1, color);
			i = j + 1;
		}
		if (y2 - y1 - 2 * r > 0) {
			context.fill(x1, y1 + r, x2, y2 - r, color);
		}
		i = 0;
		while (i < r) {
			int j = i;
			while (j + 1 < r && in[j + 1] == in[i]) {
				j++;
			}
			context.fill(x1 + in[i], y2 - 1 - j, x2 - in[i], y2 - i, color);
			i = j + 1;
		}
	}

	/** 1 piksellik yuvarlak çerçeve. */
	void roundOutline(float x, float y, float w, float h, float radius, int argb) {
		int color = withAlpha(argb);
		if ((color >>> 24) == 0) {
			return;
		}
		int x1 = sx(x);
		int y1 = sy(y);
		int x2 = Math.max(x1 + 2, sx(x + w));
		int y2 = Math.max(y1 + 2, sy(y + h));
		int r = clampRadius(Math.round(radius * scale), x2 - x1, y2 - y1);
		if (r <= 0) {
			context.fill(x1, y1, x2, y1 + 1, color);
			context.fill(x1, y2 - 1, x2, y2, color);
			context.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
			context.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
			return;
		}
		int[] in = insets(r);
		// en üst ve en alt çizgi
		context.fill(x1 + in[0], y1, x2 - in[0], y1 + 1, color);
		context.fill(x1 + in[0], y2 - 1, x2 - in[0], y2, color);
		for (int i = 1; i < r; i++) {
			int left = x1 + in[i];
			int leftEnd = x1 + Math.max(in[i] + 1, in[i - 1]);
			int right = x2 - in[i];
			int rightStart = x2 - Math.max(in[i] + 1, in[i - 1]);
			context.fill(left, y1 + i, leftEnd, y1 + i + 1, color);
			context.fill(rightStart, y1 + i, right, y1 + i + 1, color);
			context.fill(left, y2 - 1 - i, leftEnd, y2 - i, color);
			context.fill(rightStart, y2 - 1 - i, right, y2 - i, color);
		}
		if (y2 - y1 - 2 * r > 0) {
			context.fill(x1, y1 + r, x1 + 1, y2 - r, color);
			context.fill(x2 - 1, y1 + r, x2, y2 - r, color);
		}
	}

	private static int clampRadius(int r, int w, int h) {
		return Math.max(0, Math.min(Math.min(r, MAX_RADIUS), Math.min(w, h) / 2));
	}

	private static int[] insets(int r) {
		int[] cached = INSET_CACHE[r];
		if (cached != null) {
			return cached;
		}
		int[] result = new int[r];
		for (int i = 0; i < r; i++) {
			double dy = r - (i + 0.5);
			double dx = Math.sqrt(Math.max(0.0, (double) r * r - dy * dy));
			result[i] = (int) Math.round(r - dx);
		}
		INSET_CACHE[r] = result;
		return result;
	}

	// ---------------------------------------------------------------- metin

	/** Metin yerel (x, y) konumuna, ölçekli çizilir. */
	void text(String text, float x, float y, int argb) {
		int color = withAlpha(argb);
		// Minecraft alfası çok düşük renkleri opak çizer; o yüzden neredeyse görünmezse hiç çizme.
		if ((color >>> 24) < 8) {
			return;
		}
		MatrixStack matrices = context.getMatrices();
		matrices.push();
		matrices.translate(originX + x * scale, originY + y * scale, 0f);
		matrices.scale(scale, scale, 1f);
		context.drawText(font, text, 0, 0, color, true);
		matrices.pop();
	}

	/** Yerel birimde metin genişliği. */
	float textWidth(String text) {
		return font.getWidth(text);
	}

	// ---------------------------------------------------------------- kırpma

	void scissorBegin(float x, float y, float w, float h) {
		context.enableScissor(sx(x), sy(y), Math.max(sx(x) + 1, sx(x + w)), Math.max(sy(y) + 1, sy(y + h)));
	}

	void scissorEnd() {
		context.disableScissor();
	}

	// ---------------------------------------------------------------- z katmanı

	/** Tooltip / bildirim gibi her şeyin üstünde olması gereken çizimler için. */
	void pushOverlay() {
		MatrixStack matrices = context.getMatrices();
		matrices.push();
		matrices.translate(0f, 0f, 200f);
	}

	void popOverlay() {
		context.getMatrices().pop();
	}
}

package com.turgii.visuals.module;

import com.turgii.visuals.module.impl.ClockModule;
import com.turgii.visuals.module.impl.ConfigModule;
import com.turgii.visuals.module.impl.CoordinatesModule;
import com.turgii.visuals.module.impl.FpsModule;
import com.turgii.visuals.module.impl.InterfaceModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Tüm modülleri tutar; tuş atamalarını ve HUD çizimini yürütür. */
public final class ModuleManager {
	private final List<Module> modules = new ArrayList<>();
	private final List<Module> modulesView = Collections.unmodifiableList(modules);
	private final Map<Category, List<Module>> byCategory = new EnumMap<>(Category.class);

	public final InterfaceModule ui = new InterfaceModule();

	public ModuleManager() {
		for (Category category : Category.values()) {
			byCategory.put(category, new ArrayList<>());
		}
		register(new FpsModule());
		register(new CoordinatesModule());
		register(new ClockModule());
		register(ui);
		register(new ConfigModule());
	}

	private void register(Module module) {
		modules.add(module);
		byCategory.get(module.getCategory()).add(module);
	}

	public List<Module> all() {
		return modulesView;
	}

	public List<Module> inCategory(Category category) {
		return Collections.unmodifiableList(byCategory.get(category));
	}

	public boolean hasModules(Category category) {
		return !byCategory.get(category).isEmpty();
	}

	public Module byId(String id) {
		for (Module module : modules) {
			if (module.getId().equals(id)) {
				return module;
			}
		}
		return null;
	}

	/** Her client tick'inde çağrılır: modül tuş atamalarını kontrol eder. */
	public void tick(MinecraftClient client) {
		boolean screenOpen = client.currentScreen != null;
		long window = client.getWindow().getHandle();
		for (int i = 0; i < modules.size(); i++) {
			Module module = modules.get(i);
			int key = module.getKeyCode();
			if (key < 0 || !module.isToggleable()) {
				module.keyWasDown = false;
				continue;
			}
			boolean down = InputUtil.isKeyPressed(window, key);
			if (down && !module.keyWasDown && !screenOpen) {
				module.toggle();
			}
			module.keyWasDown = down;
		}
	}

	public void renderHud(DrawContext context, MinecraftClient client) {
		for (int i = 0; i < modules.size(); i++) {
			Module module = modules.get(i);
			if (module.isEnabled()) {
				module.onHudRender(context, client);
			}
		}
	}

	/** Tüm ayarları varsayılana döndürür, tuş atamalarını siler, tüm modülleri kapatır. */
	public void resetAll() {
		for (Module module : modules) {
			module.resetSettings();
			module.setKeyCode(-1);
			module.setEnabled(false);
		}
	}
}

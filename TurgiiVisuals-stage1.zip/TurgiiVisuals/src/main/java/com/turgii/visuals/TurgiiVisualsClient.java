package com.turgii.visuals;

import com.turgii.visuals.config.ConfigManager;
import com.turgii.visuals.gui.ClickGuiScreen;
import com.turgii.visuals.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Turgii Visuals giriş noktası (sadece client). */
public final class TurgiiVisualsClient implements ClientModInitializer {
	public static final String MOD_ID = "turgii_visuals";
	public static final String MOD_NAME = "Turgii Visuals";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final String VERSION = FabricLoader.getInstance().getModContainer(MOD_ID)
		.map(container -> container.getMetadata().getVersion().getFriendlyString())
		.orElse("dev");

	private static ModuleManager moduleManager;
	private static ConfigManager configManager;
	private static KeyBinding openGuiKey;

	@Override
	public void onInitializeClient() {
		moduleManager = new ModuleManager();
		configManager = new ConfigManager(moduleManager);
		configManager.load();

		openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.turgii_visuals.open_gui",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_K,
			"category.turgii_visuals"
		));

		ClientTickEvents.END_CLIENT_TICK.register(TurgiiVisualsClient::onTick);
		HudRenderCallback.EVENT.register((context, tickCounter) ->
			moduleManager.renderHud(context, MinecraftClient.getInstance()));
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> configManager.save());

		LOGGER.info("{} {} loaded (client-side visuals only).", MOD_NAME, VERSION);
	}

	private static void onTick(MinecraftClient client) {
		while (openGuiKey.wasPressed()) {
			if (client.currentScreen == null) {
				client.setScreen(new ClickGuiScreen());
			}
		}
		moduleManager.tick(client);
		configManager.tick();
	}

	public static ModuleManager modules() {
		return moduleManager;
	}

	public static ConfigManager config() {
		return configManager;
	}

	public static KeyBinding openGuiKey() {
		return openGuiKey;
	}
}

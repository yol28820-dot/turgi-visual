package com.turgii.visuals.module.impl;

import net.minecraft.client.MinecraftClient;

public final class FpsModule extends HudElementModule {
	private int lastFps = -1;
	private String cached = "FPS: 0";

	public FpsModule() {
		super("FPS", "Shows your current frames per second.", 0, 0);
	}

	@Override
	protected String text(MinecraftClient client) {
		int fps = client.getCurrentFps();
		if (fps != lastFps) {
			lastFps = fps;
			cached = "FPS: " + fps;
		}
		return cached;
	}
}

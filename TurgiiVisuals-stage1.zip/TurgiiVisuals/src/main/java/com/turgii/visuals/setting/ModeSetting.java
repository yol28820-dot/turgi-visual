package com.turgii.visuals.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class ModeSetting extends Setting<String> {
	private final String[] options;

	public ModeSetting(String name, String description, String defaultValue, String... options) {
		super(name, description, defaultValue);
		if (options.length == 0) {
			throw new IllegalArgumentException("ModeSetting needs at least one option: " + name);
		}
		this.options = options.clone();
		boolean found = false;
		for (String option : this.options) {
			if (option.equals(defaultValue)) {
				found = true;
				break;
			}
		}
		if (!found) {
			throw new IllegalArgumentException("Default '" + defaultValue + "' is not an option of " + name);
		}
	}

	public String[] getOptions() {
		return options;
	}

	public int getIndex() {
		for (int i = 0; i < options.length; i++) {
			if (options[i].equals(value)) {
				return i;
			}
		}
		return 0;
	}

	public void setIndex(int index) {
		if (index >= 0 && index < options.length) {
			set(options[index]);
		}
	}

	public boolean is(String option) {
		return value.equals(option);
	}

	@Override
	protected String sanitize(String candidate) {
		if (candidate == null) {
			return null;
		}
		for (String option : options) {
			if (option.equals(candidate)) {
				return option;
			}
		}
		return null;
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(value);
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
			set(element.getAsString());
		}
	}
}

package com.turgii.visuals.module.impl;

import com.turgii.visuals.module.Category;
import com.turgii.visuals.module.Module;
import com.turgii.visuals.setting.BooleanSetting;
import com.turgii.visuals.setting.ColorSetting;
import com.turgii.visuals.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Tek satırlık metin HUD öğesi: konum (ekranın yüzdesi), ölçek, renk, gölge ve arka plan ayarlanabilir.
 * Sürükle-bırak HUD editörü sonraki aşamada eklenecek; şimdilik konum kaydırıcılarla ayarlanır.
 */
public abstract class HudElementModule extends Module {
	private static final int MARGIN = 4;

	private final NumberSetting posX;
	private final NumberSetting posY;
	private final NumberSetting scale = add(new NumberSetting("Scale", "Size of the text.", 1.0, 0.5, 3.0, 0.1));
	private final ColorSetting color = add(new ColorSetting("Text Color", "Color of the text.", 0xFFFFFF));
	private final BooleanSetting shadow = add(new BooleanSetting("Text Shadow", "Draw a shadow behind the text.", true));
	private final BooleanSetting background = add(new BooleanSetting("Background", "Draw a dark box behind the text.", true));

	protected HudElementModule(String name, String description, int defaultX, int defaultY) {
		super(name, description, Category.HUD, true);
		this.posX = add(new NumberSetting("Position X", "Horizontal position, 0 = left edge, 100 = right edge.",
			defaultX, 0, 100, 1));
		this.posY = add(new NumberSetting("Position Y", "Vertical position, 0 = top edge, 100 = bottom edge.",
			defaultY, 0, 100, 1));
	}

	/** Gösterilecek metin; null dönerse bu karede çizilmez. Her karede çağrılır, bu yüzden önbellekle. */
	protected abstract String text(MinecraftClient client);

	@Override
	public void onHudRender(DrawContext context, MinecraftClient client) {
		if (client.options.hudHidden) {
			return;
		}
		String text = text(client);
		if (text == null) {
			return;
		}
		TextRenderer font = client.textRenderer;
		float s = scale.getFloat();
		int pad = background.isOn() ? 3 : 0;
		int boxW = font.getWidth(text) + pad * 2;
		int boxH = 9 + pad * 2;

		float x = MARGIN + (client.getWindow().getScaledWidth() - boxW * s - MARGIN * 2) * posX.getFloat() / 100f;
		float y = MARGIN + (client.getWindow().getScaledHeight() - boxH * s - MARGIN * 2) * posY.getFloat() / 100f;

		MatrixStack matrices = context.getMatrices();
		matrices.push();
		matrices.translate(x, y, 0f);
		matrices.scale(s, s, 1f);
		if (background.isOn()) {
			context.fill(0, 0, boxW, boxH, 0x90000000);
		}
		context.drawText(font, text, pad, pad, 0xFF000000 | color.get(), shadow.isOn());
		matrices.pop();
	}
}

package com.turgii.visuals.module.impl;

import net.minecraft.client.MinecraftClient;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class ClockModule extends HudElementModule {
	private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

	private long lastSecond = -1;
	private String cached = "";

	public ClockModule() {
		super("Clock", "Shows your computer's local time.", 100, 0);
	}

	@Override
	protected String text(MinecraftClient client) {
		long second = System.currentTimeMillis() / 1000L;
		if (second != lastSecond) {
			lastSecond = second;
			cached = LocalTime.now().format(FORMAT);
		}
		return cached;
	}
}

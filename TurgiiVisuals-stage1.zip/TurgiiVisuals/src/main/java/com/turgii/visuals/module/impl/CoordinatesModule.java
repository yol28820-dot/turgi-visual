package com.turgii.visuals.module.impl;

import net.minecraft.client.MinecraftClient;

import java.util.Locale;

public final class CoordinatesModule extends HudElementModule {
	private long lastX = Long.MIN_VALUE;
	private long lastY = Long.MIN_VALUE;
	private long lastZ = Long.MIN_VALUE;
	private String cached = "";

	public CoordinatesModule() {
		super("Coordinates", "Shows your X / Y / Z position.", 0, 5);
	}

	@Override
	protected String text(MinecraftClient client) {
		if (client.player == null) {
			return null;
		}
		long x = Math.round(client.player.getX() * 10.0);
		long y = Math.round(client.player.getY() * 10.0);
		long z = Math.round(client.player.getZ() * 10.0);
		if (x != lastX || y != lastY || z != lastZ) {
			lastX = x;
			lastY = y;
			lastZ = z;
			cached = String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", x / 10.0, y / 10.0, z / 10.0);
		}
		return cached;
	}
}

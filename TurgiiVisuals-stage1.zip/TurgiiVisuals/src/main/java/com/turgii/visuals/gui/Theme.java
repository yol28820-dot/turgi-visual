package com.turgii.visuals.gui;

/**
 * ClickGUI temaları. Renkler 0xRRGGBB; alfa değerleri 0..1.
 */
public enum Theme {
	//   etiket       vurgu     pencere   kart      yazı      soluk yazı kenarlık  pencereA kartA   kenarA
	DARK("Dark",       0x5B8CFF, 0x12131A, 0x1B1D27, 0xE8EAF2, 0x8A8FA3, 0x2A2D3B, 0.90f, 0.75f, 0.90f),
	PURPLE("Purple",   0xA55CFF, 0x140F1F, 0x1E1630, 0xF0E8FF, 0x9A8AB8, 0x34264F, 0.90f, 0.75f, 0.90f),
	PINK("Pink",       0xFF5CA8, 0x1C0F17, 0x2A1623, 0xFFE8F2, 0xB88AA2, 0x4A2640, 0.90f, 0.75f, 0.90f),
	BLUE("Blue",       0x3FA2FF, 0x0D1520, 0x142030, 0xE6F2FF, 0x869CB8, 0x203550, 0.90f, 0.75f, 0.90f),
	RED("Red",         0xFF4B55, 0x1A0E10, 0x281518, 0xFFE9EA, 0xB88A8E, 0x482228, 0.90f, 0.75f, 0.90f),
	CYAN("Cyan",       0x2EE6D6, 0x0B1618, 0x122426, 0xE4FFFC, 0x84B0AC, 0x1E4044, 0.90f, 0.75f, 0.90f),
	AMOLED("AMOLED",   0x00E5FF, 0x000000, 0x0A0A0A, 0xFFFFFF, 0x7A7A7A, 0x1E1E1E, 0.97f, 0.90f, 0.90f),
	DREAMCORE("Dreamcore", 0xFF9AD5, 0x1E1A3A, 0x2C2650, 0xFFF0FB, 0xB8A8D8, 0x5A4A8A, 0.82f, 0.70f, 0.90f),
	MINIMAL("Minimal", 0xDDDDDD, 0x1C1C1C, 0x262626, 0xF2F2F2, 0x8C8C8C, 0x333333, 0.92f, 0.80f, 0.70f),
	GLASS("Glass",     0x8FD3FF, 0x9DB4CC, 0xFFFFFF, 0xFFFFFF, 0xD6E2EE, 0xFFFFFF, 0.30f, 0.10f, 0.35f);

	public final String label;
	public final int accent;
	public final int window;
	public final int card;
	public final int text;
	public final int textDim;
	public final int border;
	public final float windowAlpha;
	public final float cardAlpha;
	public final float borderAlpha;

	Theme(String label, int accent, int window, int card, int text, int textDim, int border,
		  float windowAlpha, float cardAlpha, float borderAlpha) {
		this.label = label;
		this.accent = accent;
		this.window = window;
		this.card = card;
		this.text = text;
		this.textDim = textDim;
		this.border = border;
		this.windowAlpha = windowAlpha;
		this.cardAlpha = cardAlpha;
		this.borderAlpha = borderAlpha;
	}

	public static String[] labels() {
		Theme[] all = values();
		String[] out = new String[all.length];
		for (int i = 0; i < all.length; i++) {
			out[i] = all[i].label;
		}
		return out;
	}

	public static Theme byLabel(String label) {
		for (Theme theme : values()) {
			if (theme.label.equals(label)) {
				return theme;
			}
		}
		return PURPLE;
	}
}

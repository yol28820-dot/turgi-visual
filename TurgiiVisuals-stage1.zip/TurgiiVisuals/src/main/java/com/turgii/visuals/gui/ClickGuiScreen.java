package com.turgii.visuals.gui;

import com.turgii.visuals.TurgiiVisualsClient;
import com.turgii.visuals.module.Category;
import com.turgii.visuals.module.Module;
import com.turgii.visuals.module.ModuleManager;
import com.turgii.visuals.module.impl.InterfaceModule;
import com.turgii.visuals.setting.ActionSetting;
import com.turgii.visuals.setting.BooleanSetting;
import com.turgii.visuals.setting.ColorSetting;
import com.turgii.visuals.setting.ModeSetting;
import com.turgii.visuals.setting.NumberSetting;
import com.turgii.visuals.setting.Setting;
import com.turgii.visuals.util.KeyNames;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Turgii Visuals ClickGUI.
 *
 * Çizim "immediate mode": her karede kartlar çizilirken aynı anda tıklanabilir bölgeler (Hit) kaydedilir.
 * Fare olayları bir önceki karenin bölge listesini kullanır, böylece çizim ve tıklama asla ayrışmaz.
 * Tüm yerleşim "yerel" birimdedir (480x320 pencere); gerçek ekrana Gfx ölçekler.
 */
public final class ClickGuiScreen extends Screen {
	// ------------------------------------------------------------ yerleşim
	private static final int W = 480;
	private static final int H = 320;
	private static final int SIDEBAR = 112;
	private static final int HEADER = 34;
	private static final int PAD = 8;
	private static final int VX = SIDEBAR + PAD;
	private static final int VY = HEADER + PAD;
	private static final int VW = W - SIDEBAR - 2 * PAD;
	private static final int VH = H - HEADER - 2 * PAD;

	private static final int CARD_HEAD = 26;
	private static final int ROW = 20;
	private static final int SLIDER_ROW = 28;
	private static final int SUB_ROW = 18;
	private static final int PICKER_BODY = 46;
	private static final int CARD_GAP = 6;

	// ------------------------------------------------------------ tıklanabilir bölge türleri
	private static final int K_CLOSE = 1;
	private static final int K_SEARCH = 2;
	private static final int K_CAT = 3;
	private static final int K_MOD_TOGGLE = 4;
	private static final int K_MOD_HEADER = 5;
	private static final int K_BOOL = 6;
	private static final int K_SLIDER = 7;
	private static final int K_MODE_HEAD = 8;
	private static final int K_MODE_OPT = 9;
	private static final int K_COLOR_HEAD = 10;
	private static final int K_COLOR_BAR = 11;
	private static final int K_ACTION = 12;
	private static final int K_KEYBIND = 13;
	private static final int K_RESET = 14;
	private static final int K_MOD_RESET = 15;

	// ------------------------------------------------------------ oturumlar arası kalıcı GUI durumu
	private static final Map<Module, CardState> CARDS = new HashMap<>();
	private static final Map<Setting<?>, OpenState> OPEN = new HashMap<>();
	private static Category selected;
	private static String toastText = "";
	private static long toastUntil;

	private final ModuleManager mm = TurgiiVisualsClient.modules();
	private final Gfx g = new Gfx();
	private final List<Module> shown = new ArrayList<>();
	private HitBuffer building = new HitBuffer();
	private HitBuffer lastFrame = new HitBuffer();

	// animasyon / dönüşüm
	private final long openedAt = System.currentTimeMillis();
	private long lastNanos;
	private float openAnim;
	private boolean closing;
	private float sc = 1f;
	private float ox;
	private float oy;
	private float mx;
	private float my;

	// güncel kare renkleri
	private Theme th = Theme.PURPLE;
	private int ac = Theme.PURPLE.accent;
	private float bgOp = 1f;

	// kaydırma
	private float scroll;
	private float scrollTarget;
	private float contentH;
	private float clipY1 = -10000f;
	private float clipY2 = 10000f;
	private boolean scrollDrag;

	// girdi
	private String search = "";
	private boolean searchFocused;
	private boolean listDirty = true;
	private Module listening;
	private ActionSetting armed;
	private long armedUntil;

	// sürükleme (kaydırıcı / renk çubuğu)
	private int dragKind;
	private Setting<?> dragSetting;
	private int dragArg;
	private float dragX;
	private float dragW;

	// tooltip
	private int tipKind;
	private Object tipObj;
	private int tipArg;
	private float tipTime;

	public ClickGuiScreen() {
		super(Text.literal(TurgiiVisualsClient.MOD_NAME));
		ensureSelected();
	}

	// ============================================================ Screen
	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public void close() {
		if (closing) {
			return;
		}
		closing = true;
		searchFocused = false;
		listening = null;
		dragKind = 0;
		scrollDrag = false;
	}

	@Override
	public void tick() {
		if (closing && openAnim <= 0f) {
			super.close();
		}
	}

	@Override
	public void removed() {
		armed = null;
		TurgiiVisualsClient.config().saveIfDirty();
	}

	// ============================================================ çizim
	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		long nowNanos = System.nanoTime();
		float dt = lastNanos == 0L ? 0.016f : Math.min(0.1f, (nowNanos - lastNanos) / 1_000_000_000f);
		lastNanos = nowNanos;

		InterfaceModule ui = mm.ui;
		float speed = ui.animSpeed();
		openAnim = approach(openAnim, closing ? 0f : 1f, dt * 5f * speed);
		float ease = smooth(openAnim);
		if (closing && ease <= 0.001f) {
			return;
		}

		advanceAnimations(dt, speed);
		if (listDirty) {
			rebuildList();
		}

		float maxScroll = Math.max(0f, contentH - VH);
		scrollTarget = clamp(scrollTarget, 0f, maxScroll);
		scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);
		if (Math.abs(scrollTarget - scroll) < 0.05f) {
			scroll = scrollTarget;
		}
		scroll = clamp(scroll, 0f, maxScroll);

		float fit = Math.min((width - 12f) / W, (height - 12f) / H);
		float base = Math.max(0.35f, Math.min(ui.guiScale(), fit));
		sc = base * (0.94f + 0.06f * ease);
		ox = width / 2f - W * sc / 2f;
		oy = height / 2f - H * sc / 2f + (1f - ease) * 10f;
		updateMouse(mouseX, mouseY);

		th = ui.theme();
		ac = ui.accent();
		bgOp = ui.bgOpacity();
		int radius = ui.radius();

		context.fill(0, 0, width, height, ((int) (0x78 * ease)) << 24);
		g.begin(context, MinecraftClient.getInstance().textRenderer, sc, ox, oy, ease);
		clipY1 = -10000f;
		clipY2 = 10000f;

		drawFrame(ui, radius);
		drawHeader();
		drawSidebar();
		drawContentArea();
		drawOverlay(dt);

		HitBuffer swap = lastFrame;
		lastFrame = building;
		building = swap;
		building.n = 0;
	}

	private void drawFrame(InterfaceModule ui, int radius) {
		if (ui.glow()) {
			for (int i = 1; i <= 3; i++) {
				g.roundOutline(-i, -i, W + 2 * i, H + 2 * i, radius + i, Colors.argb(ac, 0.14f / i));
			}
		}
		g.roundRect(0, 0, W, H, radius, Colors.argb(th.window, th.windowAlpha * bgOp));
		g.roundOutline(0, 0, W, H, radius, Colors.argb(th.border, th.borderAlpha));
	}

	private void drawHeader() {
		g.text("TURGII", 14, 13, Colors.opaque(ac));
		g.text("VISUALS", 14 + g.textWidth("TURGII "), 13, Colors.opaque(th.text));
		g.rect(8, HEADER - 1, W - 16, 1, Colors.argb(th.border, 0.5f));

		// arama kutusu
		float sbx = SIDEBAR + PAD;
		float sby = 7;
		float sbw = W - sbx - 34;
		float sbh = 20;
		g.roundRect(sbx, sby, sbw, sbh, 5, Colors.argb(0x000000, 0.30f));
		if (searchFocused) {
			g.roundOutline(sbx, sby, sbw, sbh, 5, Colors.argb(ac, 0.9f));
		}
		String shownText = search;
		if (shownText.isEmpty() && !searchFocused) {
			g.text("Search modules...", sbx + 8, sby + 6, Colors.opaque(th.textDim));
		} else {
			float maxW = sbw - 18;
			while (g.textWidth(shownText) > maxW && shownText.length() > 1) {
				shownText = shownText.substring(1);
			}
			boolean caret = searchFocused && (System.currentTimeMillis() / 500L) % 2L == 0L;
			g.text(caret ? shownText + "_" : shownText, sbx + 8, sby + 6, Colors.opaque(th.text));
		}
		addHit(K_SEARCH, sbx, sby, sbw, sbh, null, null, 0, "Search modules and settings by name.");

		// kapat düğmesi
		float cbx = W - 28;
		float cby = 7;
		boolean closeHover = hover(cbx, cby, 20, 20);
		g.roundRect(cbx, cby, 20, 20, 5, closeHover ? Colors.argb(0xFF4B55, 0.55f) : Colors.argb(0xFFFFFF, 0.06f));
		g.text("x", cbx + (20 - g.textWidth("x")) / 2f, cby + 6, Colors.opaque(th.text));
		addHit(K_CLOSE, cbx, cby, 20, 20, null, null, 0, "Close (Esc)");
	}

	private void drawSidebar() {
		float y = HEADER + PAD;
		float w = SIDEBAR - 2 * PAD;
		for (Category category : Category.values()) {
			if (!mm.hasModules(category)) {
				continue;
			}
			boolean sel = category == selected && search.isEmpty();
			boolean hov = hover(PAD, y, w, 24);
			if (sel) {
				g.roundRect(PAD, y, w, 24, 5, Colors.argb(ac, 0.22f));
				g.roundRect(PAD, y + 5, 2, 14, 1, Colors.opaque(ac));
			} else if (hov) {
				g.roundRect(PAD, y, w, 24, 5, Colors.argb(0xFFFFFF, 0.06f));
			}
			g.text(category.label(), PAD + 12, y + 8, Colors.opaque(sel ? th.text : th.textDim));
			addHit(K_CAT, PAD, y, w, 24, null, null, category.ordinal(), null);
			y += 26;
		}
		g.rect(SIDEBAR, HEADER + 6, 1, H - HEADER - 12, Colors.argb(th.border, 0.4f));
		g.text("v" + TurgiiVisualsClient.VERSION, PAD + 12, H - 18, Colors.opaque(th.textDim));
	}

	private void drawContentArea() {
		if (shown.isEmpty()) {
			g.text(search.isEmpty() ? "No modules in this category." : "No modules match your search.",
				VX + 4, VY + 6, Colors.opaque(th.textDim));
		}
		clipY1 = VY;
		clipY2 = VY + VH;
		g.scissorBegin(VX - 2, VY, VW + 4, VH);
		float y = VY - scroll;
		for (int i = 0; i < shown.size(); i++) {
			y += drawCard(shown.get(i), VX, y, VW - 8) + CARD_GAP;
		}
		contentH = Math.max(0f, y - CARD_GAP - (VY - scroll));
		g.scissorEnd();
		clipY1 = -10000f;
		clipY2 = 10000f;

		float maxScroll = Math.max(0f, contentH - VH);
		if (contentH > VH) {
			float thumb = Math.max(24f, VH * VH / contentH);
			float travel = VH - thumb;
			float thumbY = VY + (maxScroll > 0f ? scroll / maxScroll : 0f) * travel;
			g.roundRect(VX + VW - 5, VY, 3, VH, 1.5f, Colors.argb(0xFFFFFF, 0.06f));
			g.roundRect(VX + VW - 5, thumbY, 3, thumb, 1.5f, Colors.argb(ac, 0.8f));
		}
	}

	// ------------------------------------------------------------ modül kartı
	private float drawCard(Module m, float x, float y, float w) {
		CardState cs = card(m);
		float exp = smooth(cs.expand);
		float inner = exp > 0.0005f ? contentHeight(m) : 0f;
		float h = CARD_HEAD + exp * inner;
		if (y + h < VY || y > VY + VH) {
			return h;
		}

		int cardR = Math.min(mm.ui.radius(), 6);
		float tg = smooth(cs.toggle);
		boolean headHover = hover(x, y, w, CARD_HEAD);

		g.roundRect(x, y, w, h, cardR, Colors.argb(th.card, th.cardAlpha * bgOp));
		if (m.isToggleable() && tg > 0.01f) {
			g.roundRect(x, y, w, h, cardR, Colors.argb(ac, 0.10f * tg));
		}
		if (headHover) {
			g.roundRect(x, y, w, CARD_HEAD, cardR, Colors.argb(0xFFFFFF, 0.04f));
		}
		g.roundOutline(x, y, w, h, cardR, Colors.argb(th.border, th.borderAlpha * 0.6f));
		g.text(m.getName(), x + 10, y + 9, Colors.opaque(th.text));
		addHit(K_MOD_HEADER, x, y, w, CARD_HEAD, m, null, 0, headerTip(m));

		float right = x + w - 10;
		if (m.isToggleable()) {
			float sx0 = right - 28;
			float sy0 = y + 7;
			g.roundRect(sx0, sy0, 28, 12, 6, Colors.opaque(Colors.lerp(0x3A3D4A, ac, tg)));
			g.roundRect(sx0 + 2 + tg * 16, sy0 + 2, 8, 8, 4, 0xFFFFFFFF);
			addHit(K_MOD_TOGGLE, sx0 - 4, y + 3, 36, CARD_HEAD - 6, m, null, 0,
				m.isEnabled() ? "Enabled - click to disable" : "Disabled - click to enable");
			right = sx0 - 8;
		}
		g.text(cs.open ? "v" : ">", right - 6, y + 9, Colors.opaque(th.textDim));
		right -= 16;
		if (m.isToggleable() && m.getKeyCode() >= 0) {
			String bind = "[" + KeyNames.of(m.getKeyCode()) + "]";
			g.text(bind, right - g.textWidth(bind), y + 9, Colors.opaque(th.textDim));
		}

		if (exp > 0.0005f) {
			float top = y + CARD_HEAD;
			float savedY1 = clipY1;
			float savedY2 = clipY2;
			clipY1 = Math.max(clipY1, top);
			clipY2 = Math.min(clipY2, y + h);
			g.scissorBegin(x, top, w, h - CARD_HEAD);
			g.rect(x + 8, top, w - 16, 1, Colors.argb(th.border, 0.4f));
			drawContent(m, x, top, w);
			g.scissorEnd();
			clipY1 = savedY1;
			clipY2 = savedY2;
		}
		return h;
	}

	private String headerTip(Module m) {
		return m.isToggleable()
			? m.getDescription() + " (Click: expand. Right-click: toggle.)"
			: m.getDescription() + " (Click: expand.)";
	}

	private void drawContent(Module m, float x, float top, float w) {
		float rx = x + 10;
		float rw = w - 20;
		float ctrlW = rw - 16;
		float yy = top + 4;
		for (Setting<?> s : m.getSettings()) {
			if (!s.isVisible()) {
				continue;
			}
			float rh = rowHeight(s);
			if (yy + rh > clipY1 && yy < clipY2) {
				drawSetting(m, s, rx, yy, rw, ctrlW);
			}
			yy += rh;
		}
		if (m.isToggleable()) {
			if (yy + ROW > clipY1 && yy < clipY2) {
				drawKeybindRow(m, rx, yy, rw);
			}
			yy += ROW;
		}
		if (m.hasSerializableSettings()) {
			if (yy + ROW > clipY1 && yy < clipY2) {
				boolean hov = hover(rx, yy + 1, rw, ROW - 2);
				g.roundRect(rx, yy + 1, rw, ROW - 2, 4, Colors.argb(0xFFFFFF, hov ? 0.14f : 0.07f));
				String label = "Reset Module Settings";
				g.text(label, rx + (rw - g.textWidth(label)) / 2f, yy + 6, Colors.opaque(th.textDim));
				addHit(K_MOD_RESET, rx, yy + 1, rw, ROW - 2, m, null, 0, "Resets every setting of this module to its default.");
			}
		}
	}

	private void drawSetting(Module m, Setting<?> s, float rx, float yy, float rw, float ctrlW) {
		if (s instanceof BooleanSetting b) {
			drawBoolean(m, b, rx, yy, rw, ctrlW);
		} else if (s instanceof NumberSetting n) {
			drawNumber(m, n, rx, yy, rw, ctrlW);
		} else if (s instanceof ModeSetting ms) {
			drawMode(m, ms, rx, yy, rw, ctrlW);
		} else if (s instanceof ColorSetting cs) {
			drawColor(m, cs, rx, yy, rw, ctrlW);
		} else if (s instanceof ActionSetting a) {
			drawAction(m, a, rx, yy, rw);
		}
	}

	private void drawBoolean(Module m, BooleanSetting b, float rx, float yy, float rw, float ctrlW) {
		boolean hov = hover(rx - 4, yy, rw + 8, ROW);
		if (hov) {
			g.roundRect(rx - 4, yy, rw + 8, ROW, 4, Colors.argb(0xFFFFFF, 0.05f));
		}
		g.text(b.getName(), rx, yy + 6, Colors.opaque(hov ? th.text : th.textDim));
		float bx = rx + ctrlW - 14;
		boolean on = b.isOn();
		g.roundRect(bx, yy + 3, 14, 14, 4, on ? Colors.opaque(ac) : Colors.argb(0x000000, 0.35f));
		if (!on) {
			g.roundOutline(bx, yy + 3, 14, 14, 4, Colors.argb(th.border, 0.9f));
		} else {
			g.roundRect(bx + 4, yy + 7, 6, 6, 2, 0xFFFFFFFF);
		}
		addHit(K_BOOL, rx - 4, yy, rw + 8, ROW, m, b, 0, b.getDescription());
		drawResetButton(m, b, rx, yy + 4, rw);
	}

	private void drawNumber(Module m, NumberSetting n, float rx, float yy, float rw, float ctrlW) {
		boolean hov = hover(rx - 4, yy, rw + 8, SLIDER_ROW);
		g.text(n.getName(), rx, yy + 3, Colors.opaque(hov ? th.text : th.textDim));
		String value = n.display();
		g.text(value, rx + ctrlW - g.textWidth(value), yy + 3, Colors.opaque(th.text));

		float trackY = yy + 17;
		float f = (float) ((n.get() - n.getMin()) / (n.getMax() - n.getMin()));
		f = clamp(f, 0f, 1f);
		float knobX = rx + (ctrlW - 8f) * f;
		g.roundRect(rx, trackY, ctrlW, 6, 3, Colors.argb(0x000000, 0.35f));
		g.roundRect(rx, trackY, knobX - rx + 4f, 6, 3, Colors.opaque(ac));
		g.roundRect(knobX, trackY - 1, 8, 8, 4, 0xFFFFFFFF);
		addHit(K_SLIDER, rx, yy + 12, ctrlW, 15, m, n, 0, n.getDescription());
		drawResetButton(m, n, rx, yy + 2, rw);
	}

	private void drawMode(Module m, ModeSetting ms, float rx, float yy, float rw, float ctrlW) {
		OpenState os = openState(ms);
		boolean hov = hover(rx - 4, yy, rw + 8, ROW);
		if (hov) {
			g.roundRect(rx - 4, yy, rw + 8, ROW, 4, Colors.argb(0xFFFFFF, 0.05f));
		}
		g.text(ms.getName(), rx, yy + 6, Colors.opaque(hov ? th.text : th.textDim));
		float boxW = Math.min(ctrlW * 0.6f, Math.max(60f, g.textWidth(ms.get()) + 24f));
		float boxX = rx + ctrlW - boxW;
		g.roundRect(boxX, yy + 2, boxW, ROW - 4, 4, Colors.argb(0x000000, 0.35f));
		g.text(ms.get(), boxX + 6, yy + 6, Colors.opaque(th.text));
		g.text(os.open ? "^" : "v", boxX + boxW - 10, yy + 6, Colors.opaque(th.textDim));
		addHit(K_MODE_HEAD, rx - 4, yy, rw + 8, ROW, m, ms, 0, ms.getDescription());
		drawResetButton(m, ms, rx, yy + 4, rw);

		float a = smooth(os.anim);
		if (a > 0.001f) {
			String[] options = ms.getOptions();
			float fullH = options.length * SUB_ROW + 4;
			float bodyY = yy + ROW;
			float savedY1 = clipY1;
			float savedY2 = clipY2;
			clipY1 = Math.max(clipY1, bodyY);
			clipY2 = Math.min(clipY2, bodyY + a * fullH);
			g.scissorBegin(rx, bodyY, ctrlW, a * fullH);
			g.roundRect(rx, bodyY, ctrlW, fullH, 4, Colors.argb(0x000000, 0.25f));
			for (int i = 0; i < options.length; i++) {
				float oy2 = bodyY + 2 + i * SUB_ROW;
				boolean selectedOption = i == ms.getIndex();
				if (hover(rx, oy2, ctrlW, SUB_ROW)) {
					g.roundRect(rx + 2, oy2, ctrlW - 4, SUB_ROW, 3, Colors.argb(0xFFFFFF, 0.08f));
				}
				g.text(options[i], rx + 8, oy2 + 5, Colors.opaque(selectedOption ? ac : th.text));
				addHit(K_MODE_OPT, rx, oy2, ctrlW, SUB_ROW, m, ms, i, null);
			}
			g.scissorEnd();
			clipY1 = savedY1;
			clipY2 = savedY2;
		}
	}

	private void drawColor(Module m, ColorSetting c, float rx, float yy, float rw, float ctrlW) {
		OpenState os = openState(c);
		boolean hov = hover(rx - 4, yy, rw + 8, ROW);
		if (hov) {
			g.roundRect(rx - 4, yy, rw + 8, ROW, 4, Colors.argb(0xFFFFFF, 0.05f));
		}
		g.text(c.getName(), rx, yy + 6, Colors.opaque(hov ? th.text : th.textDim));
		float swatchW = 30f;
		g.roundRect(rx + ctrlW - swatchW, yy + 3, swatchW, ROW - 6, 4, Colors.opaque(c.get()));
		g.roundOutline(rx + ctrlW - swatchW, yy + 3, swatchW, ROW - 6, 4, Colors.argb(th.border, 0.9f));
		addHit(K_COLOR_HEAD, rx - 4, yy, rw + 8, ROW, m, c, 0, c.getDescription());
		drawResetButton(m, c, rx, yy + 4, rw);

		float a = smooth(os.anim);
		if (a > 0.001f) {
			float bodyY = yy + ROW;
			float savedY1 = clipY1;
			float savedY2 = clipY2;
			clipY1 = Math.max(clipY1, bodyY);
			clipY2 = Math.min(clipY2, bodyY + a * PICKER_BODY);
			g.scissorBegin(rx, bodyY, ctrlW, a * PICKER_BODY);
			g.roundRect(rx, bodyY, ctrlW, PICKER_BODY, 4, Colors.argb(0x000000, 0.25f));
			float barX = rx + 6;
			float barW = ctrlW - 12;
			for (int bar = 0; bar < 3; bar++) {
				float barY = bodyY + 4 + bar * 14;
				for (float px = 0f; px < barW; px += 3f) {
					float f = px / barW;
					int rgb;
					if (bar == 0) {
						rgb = Colors.hsvToRgb(f, 1f, 1f);
					} else if (bar == 1) {
						rgb = Colors.hsvToRgb(c.getHue(), f, c.getVal());
					} else {
						rgb = Colors.hsvToRgb(c.getHue(), c.getSat(), f);
					}
					g.rect(barX + px, barY, Math.min(3f, barW - px), 10, Colors.opaque(rgb));
				}
				float marker = bar == 0 ? c.getHue() : (bar == 1 ? c.getSat() : c.getVal());
				float markerX = barX + barW * marker;
				g.rect(markerX - 1.5f, barY - 2, 3, 14, 0xFFFFFFFF);
				g.rect(markerX - 0.5f, barY - 1, 1, 12, 0xFF000000);
				addHit(K_COLOR_BAR, barX, barY - 2, barW, 14, m, c, bar, "Drag to change hue, saturation or brightness.");
			}
			g.scissorEnd();
			clipY1 = savedY1;
			clipY2 = savedY2;
		}
	}

	private void drawAction(Module m, ActionSetting a, float rx, float yy, float rw) {
		boolean isArmed = armed == a && System.currentTimeMillis() < armedUntil;
		boolean hov = hover(rx, yy + 1, rw, ROW - 2);
		int fill = isArmed ? Colors.argb(ac, 0.35f) : Colors.argb(0xFFFFFF, hov ? 0.14f : 0.07f);
		g.roundRect(rx, yy + 1, rw, ROW - 2, 4, fill);
		String label = isArmed ? "Click again to confirm" : a.getName();
		g.text(label, rx + (rw - g.textWidth(label)) / 2f, yy + 6, Colors.opaque(th.text));
		addHit(K_ACTION, rx, yy + 1, rw, ROW - 2, m, a, 0, a.getDescription());
	}

	private void drawKeybindRow(Module m, float rx, float yy, float rw) {
		boolean isListening = listening == m;
		g.text("Keybind", rx, yy + 6, Colors.opaque(th.textDim));
		String name = isListening ? "Press a key..." : KeyNames.of(m.getKeyCode());
		float boxW = Math.max(80f, g.textWidth(name) + 16f);
		float boxX = rx + rw - boxW;
		g.roundRect(boxX, yy + 2, boxW, ROW - 4, 4,
			isListening ? Colors.argb(ac, 0.35f) : Colors.argb(0x000000, 0.35f));
		g.text(name, boxX + (boxW - g.textWidth(name)) / 2f, yy + 6, Colors.opaque(th.text));
		addHit(K_KEYBIND, rx, yy, rw, ROW, m, null, 0,
			"Click, then press a key to toggle this module. Backspace clears it, Esc cancels. Right-click clears.");
	}

	/** Değer varsayılandan farklıysa görünen küçük "R" düğmesi. */
	private void drawResetButton(Module m, Setting<?> s, float rx, float y, float rw) {
		if (s.isDefault()) {
			return;
		}
		float bx = rx + rw - 12;
		boolean hov = hover(bx, y, 12, 12);
		g.roundRect(bx, y, 12, 12, 3, Colors.argb(0xFFFFFF, hov ? 0.20f : 0.09f));
		g.text("R", bx + 3.5f, y + 2.5f, Colors.opaque(th.text));
		addHit(K_RESET, bx, y, 12, 12, m, s, 0, "Reset to default");
	}

	// ------------------------------------------------------------ yerleşim hesapları
	private float rowHeight(Setting<?> s) {
		if (s instanceof NumberSetting) {
			return SLIDER_ROW;
		}
		if (s instanceof ModeSetting ms) {
			return ROW + smooth(openState(s).anim) * (ms.getOptions().length * SUB_ROW + 4);
		}
		if (s instanceof ColorSetting) {
			return ROW + smooth(openState(s).anim) * PICKER_BODY;
		}
		return ROW;
	}

	private float contentHeight(Module m) {
		float total = 4f;
		for (Setting<?> s : m.getSettings()) {
			if (s.isVisible()) {
				total += rowHeight(s);
			}
		}
		if (m.isToggleable()) {
			total += ROW;
		}
		if (m.hasSerializableSettings()) {
			total += ROW;
		}
		return total + 4f;
	}

	// ------------------------------------------------------------ overlay (tooltip + bildirim)
	private void drawOverlay(float dt) {
		Hit top = topHitAt(lastFrame);
		if (top != null && top.tip != null && dragKind == 0 && !scrollDrag) {
			Object obj = top.setting != null ? top.setting : top.module;
			if (top.kind == tipKind && obj == tipObj && top.arg == tipArg) {
				tipTime += dt;
			} else {
				tipKind = top.kind;
				tipObj = obj;
				tipArg = top.arg;
				tipTime = 0f;
			}
			if (tipTime > 0.4f) {
				drawTooltip(top.tip);
			}
		} else {
			tipObj = null;
			tipTime = 0f;
		}

		long now = System.currentTimeMillis();
		if (now < toastUntil && !toastText.isEmpty()) {
			float fade = Math.min(1f, (toastUntil - now) / 400f);
			float textW = g.textWidth(toastText);
			float boxW = Math.min(W - 16f, textW + 20f);
			float boxX = (W - boxW) / 2f;
			float boxY = H - 30f;
			g.pushOverlay();
			g.roundRect(boxX, boxY, boxW, 20, 6, Colors.argb(0x0A0A12, 0.92f * fade));
			g.roundOutline(boxX, boxY, boxW, 20, 6, Colors.argb(ac, 0.9f * fade));
			g.text(toastText, boxX + 10, boxY + 6, Colors.argb(0xFFFFFF, fade));
			g.popOverlay();
		}
	}

	private void drawTooltip(String tip) {
		List<String> lines = wrap(tip, 190f);
		float textW = 0f;
		for (String line : lines) {
			textW = Math.max(textW, g.textWidth(line));
		}
		float boxW = textW + 12f;
		float boxH = lines.size() * 11f + 6f;
		float tx = mx + 12f;
		float ty = my + 14f;
		if (tx + boxW > W - 4f) {
			tx = W - 4f - boxW;
		}
		if (ty + boxH > H - 4f) {
			ty = my - boxH - 6f;
		}
		g.pushOverlay();
		g.roundRect(tx, ty, boxW, boxH, 4, 0xF0101018);
		g.roundOutline(tx, ty, boxW, boxH, 4, Colors.argb(ac, 0.8f));
		for (int i = 0; i < lines.size(); i++) {
			g.text(lines.get(i), tx + 6, ty + 4 + i * 11f, 0xFFE8EAF2);
		}
		g.popOverlay();
	}

	private List<String> wrap(String text, float maxWidth) {
		List<String> lines = new ArrayList<>();
		StringBuilder line = new StringBuilder();
		for (String word : text.split(" ")) {
			String candidate = line.isEmpty() ? word : line + " " + word;
			if (g.textWidth(candidate) > maxWidth && !line.isEmpty()) {
				lines.add(line.toString());
				line.setLength(0);
				line.append(word);
			} else {
				line.setLength(0);
				line.append(candidate);
			}
		}
		if (!line.isEmpty()) {
			lines.add(line.toString());
		}
		return lines;
	}

	// ============================================================ girdi
	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (closing) {
			return true;
		}
		updateMouse(mouseX, mouseY);
		if (button != 0 && button != 1) {
			return false;
		}
		Hit hit = topHitAt(lastFrame);
		if (hit == null || hit.kind != K_SEARCH) {
			searchFocused = false;
		}
		if (hit == null || hit.kind != K_KEYBIND) {
			listening = null;
		}
		if (hit == null) {
			if (button == 0 && mx >= VX && mx < VX + VW && my >= VY && my < VY + VH) {
				scrollDrag = true;
			}
			return true;
		}
		handleHit(hit, button);
		return true;
	}

	private void handleHit(Hit hit, int button) {
		Module m = hit.module;
		Setting<?> s = hit.setting;
		switch (hit.kind) {
			case K_CLOSE -> close();
			case K_SEARCH -> {
				searchFocused = true;
				listening = null;
			}
			case K_CAT -> {
				selected = Category.values()[hit.arg];
				search = "";
				listDirty = true;
				scroll = 0f;
				scrollTarget = 0f;
				contentH = 0f;
			}
			case K_MOD_TOGGLE -> m.toggle();
			case K_MOD_HEADER -> {
				if (button == 1 && m.isToggleable()) {
					m.toggle();
				} else {
					CardState cs = card(m);
					cs.open = !cs.open;
				}
			}
			case K_BOOL -> {
				if (button == 1) {
					s.reset();
				} else {
					((BooleanSetting) s).toggle();
				}
			}
			case K_SLIDER -> {
				if (button == 1) {
					s.reset();
				} else {
					beginDrag(K_SLIDER, s, 0, hit);
				}
			}
			case K_MODE_HEAD, K_COLOR_HEAD -> {
				if (button == 1) {
					s.reset();
				} else {
					OpenState os = openState(s);
					os.open = !os.open;
				}
			}
			case K_MODE_OPT -> {
				((ModeSetting) s).setIndex(hit.arg);
				openState(s).open = false;
			}
			case K_COLOR_BAR -> beginDrag(K_COLOR_BAR, s, hit.arg, hit);
			case K_ACTION -> runAction((ActionSetting) s);
			case K_KEYBIND -> {
				if (button == 1) {
					m.setKeyCode(-1);
				} else {
					listening = m;
				}
			}
			case K_RESET -> s.reset();
			case K_MOD_RESET -> {
				m.resetSettings();
				toast("Reset " + m.getName() + " settings.");
			}
			default -> {
			}
		}
	}

	private void beginDrag(int kind, Setting<?> setting, int arg, Hit hit) {
		dragKind = kind;
		dragSetting = setting;
		dragArg = arg;
		dragX = hit.x;
		dragW = hit.w;
		applyDrag();
	}

	private void applyDrag() {
		if (dragKind == K_SLIDER && dragSetting instanceof NumberSetting n) {
			double f = clamp((mx - (dragX + 4f)) / (dragW - 8f), 0f, 1f);
			n.set(n.getMin() + f * (n.getMax() - n.getMin()));
		} else if (dragKind == K_COLOR_BAR && dragSetting instanceof ColorSetting c) {
			float f = clamp((mx - dragX) / dragW, 0f, 1f);
			switch (dragArg) {
				case 0 -> c.setHsv(f, c.getSat(), c.getVal());
				case 1 -> c.setHsv(c.getHue(), f, c.getVal());
				default -> c.setHsv(c.getHue(), c.getSat(), f);
			}
		}
	}

	private void runAction(ActionSetting action) {
		long now = System.currentTimeMillis();
		if (action.needsConfirm() && !(armed == action && now < armedUntil)) {
			armed = action;
			armedUntil = now + 3000L;
			return;
		}
		armed = null;
		toast(action.run());
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		updateMouse(mouseX, mouseY);
		if (dragKind != 0) {
			applyDrag();
			return true;
		}
		if (scrollDrag) {
			float maxScroll = Math.max(0f, contentH - VH);
			scroll = clamp(scroll - (float) (deltaY / sc), 0f, maxScroll);
			scrollTarget = scroll;
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		dragKind = 0;
		dragSetting = null;
		scrollDrag = false;
		return true;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		updateMouse(mouseX, mouseY);
		if (mx >= VX && mx < VX + VW && my >= VY && my < VY + VH) {
			float maxScroll = Math.max(0f, contentH - VH);
			scrollTarget = clamp(scrollTarget - (float) verticalAmount * 26f, 0f, maxScroll);
			return true;
		}
		return false;
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (listening != null) {
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
				listening.setKeyCode(-1);
			} else if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
				listening.setKeyCode(keyCode);
			}
			listening = null;
			return true;
		}
		if (searchFocused) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				if (search.isEmpty()) {
					searchFocused = false;
				} else {
					search = "";
					listDirty = true;
				}
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
				searchFocused = false;
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
				if (!search.isEmpty()) {
					search = search.substring(0, search.length() - 1);
					listDirty = true;
					scroll = 0f;
					scrollTarget = 0f;
				}
				return true;
			}
		}
		if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
			close();
			return true;
		}
		// Açma tuşuyla tekrar kapat (açılırken tuş tekrarı yüzünden hemen kapanmasın diye kısa bekleme).
		if (System.currentTimeMillis() - openedAt > 300L
			&& TurgiiVisualsClient.openGuiKey().matchesKey(keyCode, scanCode)) {
			close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean charTyped(char chr, int modifiers) {
		if (!searchFocused) {
			return false;
		}
		if (chr < 32 || chr == 127 || chr == 167) {
			return false;
		}
		if (search.length() < 24) {
			search = search + chr;
			listDirty = true;
			scroll = 0f;
			scrollTarget = 0f;
		}
		return true;
	}

	// ============================================================ yardımcılar
	static void toast(String message) {
		toastText = message == null ? "" : message;
		toastUntil = System.currentTimeMillis() + 2800L;
	}

	private void updateMouse(double mouseX, double mouseY) {
		mx = (float) ((mouseX - ox) / sc);
		my = (float) ((mouseY - oy) / sc);
	}

	private boolean hover(float x, float y, float w, float h) {
		return mx >= x && mx < x + w && my >= y && my < y + h && my >= clipY1 && my < clipY2;
	}

	private Hit addHit(int kind, float x, float y, float w, float h, Module module, Setting<?> setting,
					   int arg, String tip) {
		float y1 = Math.max(y, clipY1);
		float y2 = Math.min(y + h, clipY2);
		if (y2 <= y1) {
			return null;
		}
		Hit hit = building.next();
		hit.set(kind, x, y1, w, y2 - y1, module, setting, arg, tip);
		return hit;
	}

	private Hit topHitAt(HitBuffer buffer) {
		for (int i = buffer.n - 1; i >= 0; i--) {
			Hit hit = buffer.arr[i];
			if (mx >= hit.x && mx < hit.x + hit.w && my >= hit.y && my < hit.y + hit.h) {
				return hit;
			}
		}
		return null;
	}

	private void ensureSelected() {
		if (selected != null && mm.hasModules(selected)) {
			return;
		}
		selected = null;
		for (Category category : Category.values()) {
			if (mm.hasModules(category)) {
				selected = category;
				return;
			}
		}
	}

	private void rebuildList() {
		shown.clear();
		String query = search.trim().toLowerCase(Locale.ROOT);
		if (query.isEmpty()) {
			if (selected != null) {
				shown.addAll(mm.inCategory(selected));
			}
		} else {
			for (Module module : mm.all()) {
				if (matches(module, query)) {
					shown.add(module);
				}
			}
		}
		listDirty = false;
	}

	private static boolean matches(Module module, String query) {
		if (module.getName().toLowerCase(Locale.ROOT).contains(query)
			|| module.getDescription().toLowerCase(Locale.ROOT).contains(query)) {
			return true;
		}
		for (Setting<?> setting : module.getSettings()) {
			if (setting.getName().toLowerCase(Locale.ROOT).contains(query)) {
				return true;
			}
		}
		return false;
	}

	private void advanceAnimations(float dt, float speed) {
		float step = dt * speed * 6f;
		for (CardState card : CARDS.values()) {
			card.expand = approach(card.expand, card.open ? 1f : 0f, step);
			card.toggle = approach(card.toggle, card.module.isEnabled() ? 1f : 0f, step * 1.3f);
		}
		for (OpenState state : OPEN.values()) {
			state.anim = approach(state.anim, state.open ? 1f : 0f, step * 1.3f);
		}
	}

	private static CardState card(Module module) {
		return CARDS.computeIfAbsent(module, CardState::new);
	}

	private static OpenState openState(Setting<?> setting) {
		return OPEN.computeIfAbsent(setting, key -> new OpenState());
	}

	private static float approach(float current, float target, float step) {
		return current < target ? Math.min(target, current + step) : Math.max(target, current - step);
	}

	private static float smooth(float t) {
		float k = clamp(t, 0f, 1f);
		return k * k * (3f - 2f * k);
	}

	private static float clamp(float value, float min, float max) {
		return value < min ? min : Math.min(value, max);
	}

	// ============================================================ iç sınıflar
	private static final class CardState {
		final Module module;
		boolean open;
		float expand;
		float toggle;

		CardState(Module module) {
			this.module = module;
			this.toggle = module.isEnabled() ? 1f : 0f;
		}
	}

	private static final class OpenState {
		boolean open;
		float anim;
	}

	private static final class Hit {
		int kind;
		float x;
		float y;
		float w;
		float h;
		Module module;
		Setting<?> setting;
		int arg;
		String tip;

		void set(int kind, float x, float y, float w, float h, Module module, Setting<?> setting,
				 int arg, String tip) {
			this.kind = kind;
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
			this.module = module;
			this.setting = setting;
			this.arg = arg;
			this.tip = tip;
		}
	}

	/** Her karede yeniden kullanılan, ek tahsis yapmayan bölge listesi. */
	private static final class HitBuffer {
		Hit[] arr = new Hit[128];
		int n;

		Hit next() {
			if (n == arr.length) {
				arr = Arrays.copyOf(arr, n * 2);
			}
			Hit hit = arr[n];
			if (hit == null) {
				hit = new Hit();
				arr[n] = hit;
			}
			n++;
			return hit;
		}
	}
}

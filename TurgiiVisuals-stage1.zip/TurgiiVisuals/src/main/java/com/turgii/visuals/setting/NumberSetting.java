package com.turgii.visuals.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public final class NumberSetting extends Setting<Double> {
	private final double min;
	private final double max;
	private final double step;

	public NumberSetting(String name, String description, double defaultValue, double min, double max, double step) {
		super(name, description, defaultValue);
		this.min = min;
		this.max = max;
		this.step = step;
	}

	public double getMin() {
		return min;
	}

	public double getMax() {
		return max;
	}

	public double getStep() {
		return step;
	}

	public float getFloat() {
		return value.floatValue();
	}

	public int getInt() {
		return (int) Math.round(value);
	}

	@Override
	protected Double sanitize(Double candidate) {
		if (candidate == null || candidate.isNaN() || candidate.isInfinite()) {
			return null;
		}
		double clamped = Math.max(min, Math.min(max, candidate));
		if (step > 0) {
			clamped = min + Math.round((clamped - min) / step) * step;
			clamped = Math.max(min, Math.min(max, clamped));
		}
		return Math.round(clamped * 1_000_000d) / 1_000_000d;
	}

	/** GUI'de gösterilecek metin. */
	public String display() {
		if (step >= 1) {
			return String.valueOf(Math.round(value));
		}
		if (step >= 0.1) {
			return String.format(Locale.ROOT, "%.1f", value);
		}
		return String.format(Locale.ROOT, "%.2f", value);
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(value);
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
			set(element.getAsDouble());
		}
	}
}

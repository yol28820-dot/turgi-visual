package com.turgii.visuals.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

import java.util.function.Supplier;

/**
 * GUI'de buton olarak görünen ayar. Tıklanınca eylem çalışır ve GUI'de gösterilecek bir mesaj döner.
 * Config dosyasına yazılmaz.
 */
public final class ActionSetting extends Setting<Boolean> {
	private final boolean needsConfirm;
	private final Supplier<String> action;

	public ActionSetting(String name, String description, boolean needsConfirm, Supplier<String> action) {
		super(name, description, false);
		this.needsConfirm = needsConfirm;
		this.action = action;
	}

	public boolean needsConfirm() {
		return needsConfirm;
	}

	/** Eylemi çalıştırır, kullanıcıya gösterilecek mesajı döndürür. */
	public String run() {
		return action.get();
	}

	@Override
	public boolean isSerializable() {
		return false;
	}

	@Override
	public JsonElement toJson() {
		return JsonNull.INSTANCE;
	}

	@Override
	public void fromJson(JsonElement element) {
		// butonun saklanacak değeri yok
	}
}

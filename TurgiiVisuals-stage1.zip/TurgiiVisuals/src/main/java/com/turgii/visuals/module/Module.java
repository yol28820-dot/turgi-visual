package com.turgii.visuals.module;

import com.turgii.visuals.config.ConfigManager;
import com.turgii.visuals.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Tüm modüllerin tabanı. "toggleable = false" olan modüller sadece ayar tutar (ör. Interface, Config)
 * ve GUI'de açma/kapama anahtarı göstermez.
 */
public class Module {
	private final String name;
	private final String description;
	private final String id;
	private final Category category;
	private final boolean toggleable;
	private final List<Setting<?>> settings = new ArrayList<>();
	private final List<Setting<?>> settingsView = Collections.unmodifiableList(settings);

	private boolean enabled;
	private int keyCode = -1;
	boolean keyWasDown;

	public Module(String name, String description, Category category, boolean toggleable) {
		this.name = name;
		this.description = description;
		this.category = category;
		this.toggleable = toggleable;
		this.id = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
	}

	protected <S extends Setting<?>> S add(S setting) {
		settings.add(setting);
		return setting;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	/** Config dosyalarında kullanılan kararlı anahtar. */
	public String getId() {
		return id;
	}

	public Category getCategory() {
		return category;
	}

	public boolean isToggleable() {
		return toggleable;
	}

	public List<Setting<?>> getSettings() {
		return settingsView;
	}

	public boolean hasSerializableSettings() {
		for (Setting<?> setting : settings) {
			if (setting.isSerializable()) {
				return true;
			}
		}
		return false;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean value) {
		if (!toggleable || enabled == value) {
			return;
		}
		enabled = value;
		ConfigManager.markDirty();
		if (value) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public int getKeyCode() {
		return keyCode;
	}

	public void setKeyCode(int code) {
		if (keyCode != code) {
			keyCode = code;
			ConfigManager.markDirty();
		}
	}

	public void resetSettings() {
		for (Setting<?> setting : settings) {
			if (setting.isSerializable()) {
				setting.reset();
			}
		}
	}

	protected void onEnable() {
	}

	protected void onDisable() {
	}

	/** Sadece modül açıkken, HUD çizim sırasında çağrılır. */
	public void onHudRender(DrawContext context, MinecraftClient client) {
	}
}

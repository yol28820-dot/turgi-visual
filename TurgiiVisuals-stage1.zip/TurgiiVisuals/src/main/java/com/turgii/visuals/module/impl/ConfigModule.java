package com.turgii.visuals.module.impl;

import com.turgii.visuals.TurgiiVisualsClient;
import com.turgii.visuals.module.Category;
import com.turgii.visuals.module.Module;
import com.turgii.visuals.setting.ActionSetting;

/** Kaydet / Yükle / Sıfırla / İçe aktar / Dışa aktar düğmeleri. */
public final class ConfigModule extends Module {

	public ConfigModule() {
		super("Config", "Save, load, reset, import and export your settings (config/turgii-visuals/).",
			Category.SETTINGS, false);
		add(new ActionSetting("Save Now",
			"Writes config.json, hud.json and keybinds.json right now. Settings also auto-save.",
			false, () -> TurgiiVisualsClient.config().save()));
		add(new ActionSetting("Reload From Disk",
			"Discards unsaved changes and reloads the three config files.",
			false, () -> TurgiiVisualsClient.config().reload()));
		add(new ActionSetting("Export Profile",
			"Writes everything into config/turgii-visuals/export/turgii-profile.json so you can share it.",
			false, () -> TurgiiVisualsClient.config().exportProfile()));
		add(new ActionSetting("Import Profile",
			"Loads config/turgii-visuals/export/turgii-profile.json and applies it.",
			false, () -> TurgiiVisualsClient.config().importProfile()));
		add(new ActionSetting("Reset Everything",
			"Resets every setting, every keybind and disables every module. Needs a second click to confirm.",
			true, () -> TurgiiVisualsClient.config().resetAll()));
	}
}

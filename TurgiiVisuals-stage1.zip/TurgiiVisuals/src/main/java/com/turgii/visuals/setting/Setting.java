package com.turgii.visuals.setting;

import com.google.gson.JsonElement;
import com.turgii.visuals.config.ConfigManager;

import java.util.function.BooleanSupplier;

/**
 * Bir modülün ayarı. Değer değiştiğinde config "kirli" işaretlenir ve kısa süre sonra otomatik kaydedilir.
 */
public abstract class Setting<T> {
	private final String name;
	private final String description;
	private final T defaultValue;
	protected T value;
	private BooleanSupplier visibility = () -> true;

	protected Setting(String name, String description, T defaultValue) {
		this.name = name;
		this.description = description;
		this.defaultValue = defaultValue;
		this.value = defaultValue;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public T get() {
		return value;
	}

	public T getDefault() {
		return defaultValue;
	}

	public void set(T newValue) {
		T clean = sanitize(newValue);
		if (clean == null || clean.equals(value)) {
			return;
		}
		value = clean;
		ConfigManager.markDirty();
	}

	/** Gelen değeri geçerli aralığa getirir; geçersizse null döner. */
	protected T sanitize(T candidate) {
		return candidate;
	}

	public void reset() {
		set(defaultValue);
	}

	public boolean isDefault() {
		return defaultValue.equals(value);
	}

	public boolean isVisible() {
		return visibility.getAsBoolean();
	}

	public void visibleWhen(BooleanSupplier condition) {
		this.visibility = condition;
	}

	/** Config dosyasına yazılsın mı? (Butonlar yazılmaz.) */
	public boolean isSerializable() {
		return true;
	}

	public abstract JsonElement toJson();

	public abstract void fromJson(JsonElement element);
}
